vtigerCRM-EventHandler
======================

This Extension will implement a improved Version of Eventhandling in vtigerCRM.

The downloads are compatible to the ModuleManager. 
If you want to use this Extension you have to manualle modify Core files of vtigerCRM to implement the Events.

